package ravensproject.models.RavenObjectLevel;

/**
 * Created by guoliangwang on 6/28/15.
 * Interface for changes or transformations in RavensObjects
 */
public interface ROTransformationInterface {
    String getAttributeKeyName();
}
